import React from "react";

const Contact = () => {
  return (
    <div>
      <h1>Contact Us</h1>
      <p>Reach out to us for any queries or support.</p>
    </div>
  );
};

export default Contact;
