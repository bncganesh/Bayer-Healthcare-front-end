import { Link } from "react-router-dom";

const Sidebar = () => {
    return(
        <aside className="sidebar">
        <h2>Bayer Health</h2>
        <ul>
          <li><Link to="/dashboard">Dashboard</Link></li>
          <li><Link to="/profile">My Profile</Link></li>
          <li><Link to="/healthmetrics">Health Metrics</Link></li>
          <li><Link to="/messages">Messages</Link></li>
          <li><Link to="#">Logout</Link></li>
        </ul>
      </aside>
    )
}
export default Sidebar;