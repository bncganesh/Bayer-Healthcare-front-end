import React from "react";

const HealthTopics = () => {
  return (
    <div>
      <h1>Health Topics</h1>
      <p>Explore various health topics to stay informed.</p>
    </div>
  );
};

export default HealthTopics;
