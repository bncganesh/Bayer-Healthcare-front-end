import React from "react";

const Resources = () => {
  return (
    <div>
      <h1>Resources</h1>
      <p>Find useful health resources and guides.</p>
    </div>
  );
};

export default Resources;
